"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* __next_internal_client_entry_do_not_use__ default auto */ \n\n\nconst App = ({ Component, pageProps })=>{\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        console.log(\"Is window defined:\", \"undefined\" !== \"undefined\");\n        // Проверяем, что код выполняется в браузере\n        if (true) return;\n        Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! react-facebook-pixel */ \"react-facebook-pixel\", 23)).then((x)=>x.default).then((ReactPixel)=>{\n            console.log(\"ReactPixel loaded\");\n            ReactPixel.init(\"880165347354430\"); // Ваш Pixel ID\n            ReactPixel.pageView(); // Первый вызов pageView\n            console.log(\"Page view sent\");\n            // Обработка смены маршрута\n            const handleRouteChange = ()=>{\n                console.log(\"Route changed, sending page view\");\n                ReactPixel.pageView();\n            };\n            router.events.on(\"routeChangeComplete\", handleRouteChange);\n            // Убираем обработчик при размонтировании\n            return ()=>{\n                router.events.off(\"routeChangeComplete\", handleRouteChange);\n            };\n        }).catch((error)=>{\n            console.error(\"Error loading ReactPixel:\", error);\n        });\n    }, [\n        router.events\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n        ...pageProps\n    }, void 0, false, {\n        fileName: \"D:\\\\Programming\\\\Next\\\\ilevel\\\\pages\\\\_app.tsx\",\n        lineNumber: 39,\n        columnNumber: 10\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUNrQztBQUNNO0FBR3hDLE1BQU1FLE1BQU0sQ0FBQyxFQUFFQyxTQUFTLEVBQUVDLFNBQVMsRUFBWTtJQUM3QyxNQUFNQyxTQUFTSixzREFBU0E7SUFFeEJELGdEQUFTQSxDQUFDO1FBQ1JNLFFBQVFDLEdBQUcsQ0FBQyxzQkFBc0IsZ0JBQWtCO1FBQ3BELDRDQUE0QztRQUM1QyxJQUFJLElBQWtCLEVBQWE7UUFFbkMsOElBQU8sQ0FDSkMsSUFBSSxDQUFDLENBQUNDLElBQU1BLEVBQUVDLE9BQU8sRUFDckJGLElBQUksQ0FBQyxDQUFDRztZQUNMTCxRQUFRQyxHQUFHLENBQUM7WUFDWkksV0FBV0MsSUFBSSxDQUFDLG9CQUFvQixlQUFlO1lBQ25ERCxXQUFXRSxRQUFRLElBQUksd0JBQXdCO1lBQy9DUCxRQUFRQyxHQUFHLENBQUM7WUFFWiwyQkFBMkI7WUFDM0IsTUFBTU8sb0JBQW9CO2dCQUN4QlIsUUFBUUMsR0FBRyxDQUFDO2dCQUNaSSxXQUFXRSxRQUFRO1lBQ3JCO1lBQ0FSLE9BQU9VLE1BQU0sQ0FBQ0MsRUFBRSxDQUFDLHVCQUF1QkY7WUFFeEMseUNBQXlDO1lBQ3pDLE9BQU87Z0JBQ0xULE9BQU9VLE1BQU0sQ0FBQ0UsR0FBRyxDQUFDLHVCQUF1Qkg7WUFDM0M7UUFDRixHQUNDSSxLQUFLLENBQUMsQ0FBQ0M7WUFDTmIsUUFBUWEsS0FBSyxDQUFDLDZCQUE2QkE7UUFDN0M7SUFDSixHQUFHO1FBQUNkLE9BQU9VLE1BQU07S0FBQztJQUVsQixxQkFBTyw4REFBQ1o7UUFBVyxHQUFHQyxTQUFTOzs7Ozs7QUFDakM7QUFFQSxpRUFBZUYsR0FBR0EsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2lsZXZlbC8uL3BhZ2VzL19hcHAudHN4PzJmYmUiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCJcclxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XHJcbmltcG9ydCB7IEFwcFByb3BzIH0gZnJvbSAnbmV4dC9hcHAnO1xyXG5cclxuY29uc3QgQXBwID0gKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfTogQXBwUHJvcHMpID0+IHtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnNvbGUubG9nKCdJcyB3aW5kb3cgZGVmaW5lZDonLCB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyk7XHJcbiAgICAvLyDQn9GA0L7QstC10YDRj9C10LwsINGH0YLQviDQutC+0LQg0LLRi9C/0L7Qu9C90Y/QtdGC0YHRjyDQsiDQsdGA0LDRg9C30LXRgNC1XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybjtcclxuXHJcbiAgICBpbXBvcnQoJ3JlYWN0LWZhY2Vib29rLXBpeGVsJylcclxuICAgICAgLnRoZW4oKHgpID0+IHguZGVmYXVsdClcclxuICAgICAgLnRoZW4oKFJlYWN0UGl4ZWwpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZygnUmVhY3RQaXhlbCBsb2FkZWQnKTtcclxuICAgICAgICBSZWFjdFBpeGVsLmluaXQoJzg4MDE2NTM0NzM1NDQzMCcpOyAvLyDQktCw0YggUGl4ZWwgSURcclxuICAgICAgICBSZWFjdFBpeGVsLnBhZ2VWaWV3KCk7IC8vINCf0LXRgNCy0YvQuSDQstGL0LfQvtCyIHBhZ2VWaWV3XHJcbiAgICAgICAgY29uc29sZS5sb2coJ1BhZ2UgdmlldyBzZW50Jyk7XHJcblxyXG4gICAgICAgIC8vINCe0LHRgNCw0LHQvtGC0LrQsCDRgdC80LXQvdGLINC80LDRgNGI0YDRg9GC0LBcclxuICAgICAgICBjb25zdCBoYW5kbGVSb3V0ZUNoYW5nZSA9ICgpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKCdSb3V0ZSBjaGFuZ2VkLCBzZW5kaW5nIHBhZ2UgdmlldycpO1xyXG4gICAgICAgICAgUmVhY3RQaXhlbC5wYWdlVmlldygpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgcm91dGVyLmV2ZW50cy5vbigncm91dGVDaGFuZ2VDb21wbGV0ZScsIGhhbmRsZVJvdXRlQ2hhbmdlKTtcclxuXHJcbiAgICAgICAgLy8g0KPQsdC40YDQsNC10Lwg0L7QsdGA0LDQsdC+0YLRh9C40Log0L/RgNC4INGA0LDQt9C80L7QvdGC0LjRgNC+0LLQsNC90LjQuFxyXG4gICAgICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgICAgICByb3V0ZXIuZXZlbnRzLm9mZigncm91dGVDaGFuZ2VDb21wbGV0ZScsIGhhbmRsZVJvdXRlQ2hhbmdlKTtcclxuICAgICAgICB9O1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgbG9hZGluZyBSZWFjdFBpeGVsOicsIGVycm9yKTtcclxuICAgICAgfSk7XHJcbiAgfSwgW3JvdXRlci5ldmVudHNdKTtcclxuXHJcbiAgcmV0dXJuIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz47XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHA7XHJcbiJdLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VSb3V0ZXIiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJyb3V0ZXIiLCJjb25zb2xlIiwibG9nIiwidGhlbiIsIngiLCJkZWZhdWx0IiwiUmVhY3RQaXhlbCIsImluaXQiLCJwYWdlVmlldyIsImhhbmRsZVJvdXRlQ2hhbmdlIiwiZXZlbnRzIiwib24iLCJvZmYiLCJjYXRjaCIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ "react-facebook-pixel":
/*!***************************************!*\
  !*** external "react-facebook-pixel" ***!
  \***************************************/
/***/ ((module) => {

module.exports = require("react-facebook-pixel");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc"], () => (__webpack_exec__("./pages/_app.tsx")));
module.exports = __webpack_exports__;

})();