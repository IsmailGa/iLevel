import React from 'react';
import ReactPixel from 'react-facebook-pixel';

ReactPixel.init('880165347354430');
ReactPixel.pageView();

const TestPage = () => {
  return <div>Test Page for Facebook Pixel</div>;
};

export default TestPage;
