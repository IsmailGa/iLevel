"use client"
import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { AppProps } from 'next/app';

const App = ({ Component, pageProps }: AppProps) => {
  const router = useRouter();

  useEffect(() => {
    console.log('Is window defined:', typeof window !== 'undefined');
    // Проверяем, что код выполняется в браузере
    if (typeof window === 'undefined') return;

    import('react-facebook-pixel')
      .then((x) => x.default)
      .then((ReactPixel) => {
        console.log('ReactPixel loaded');
        ReactPixel.init('880165347354430'); // Ваш Pixel ID
        ReactPixel.pageView(); // Первый вызов pageView
        console.log('Page view sent');

        // Обработка смены маршрута
        const handleRouteChange = () => {
          console.log('Route changed, sending page view');
          ReactPixel.pageView();
        };
        router.events.on('routeChangeComplete', handleRouteChange);

        // Убираем обработчик при размонтировании
        return () => {
          router.events.off('routeChangeComplete', handleRouteChange);
        };
      })
      .catch((error) => {
        console.error('Error loading ReactPixel:', error);
      });
  }, [router.events]);

  return <Component {...pageProps} />;
};

export default App;
